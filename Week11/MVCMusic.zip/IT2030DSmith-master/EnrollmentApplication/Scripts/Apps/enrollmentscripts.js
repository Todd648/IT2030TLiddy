﻿function searchFailedStudents() {
    $("#studentsearchresults").html("Sorry, there was a problem with the search.");
}

function searchFailedCourses() {
    $("#coursesearchresults").html("Sorry, there was a problem with the search.");
}